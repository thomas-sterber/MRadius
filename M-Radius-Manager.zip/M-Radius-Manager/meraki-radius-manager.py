#!/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# --------------------------------------------------------
#

__author__      		= "Thomas Sterber"
__copyright__   		= "Copyright January 2023"
__license__     		= "GPL"
__email__       		= "thomas.sterber@meraki.net"
__version__     		= "CLI 2.4"
__used_python__			= '3.9.2'
__last_test__			= 'January 2023'
__MS_version__			= 'MR29.5'
__MR_version__			= 'MS15.18'
__Freeradius_Version__ 	= 'FreeRADIUS Version 3.0.17'
__Raspberry_OS__ 		= 'debian bullseye , Raspberry Pi OS lite (64 Bit)'


info = f'''
	Meraki Freeradius Manager for Raspberry Pi
	=============================================================

	Release version : {__version__}
	Radius version	: {__Freeradius_Version__}
	Raspberry_OS	: {__Raspberry_OS__}

	written by {__author__} , ({__email__})

	This software could be used for POC testings on your
	own risk.

	Requirements:
		Raspberry running Debian 11 with root ssh access.
			installed tools
				- pgrep  (sudo apt-get install pgrep)

	clients.conf allows all clients (devices like MR,..)
	client secret == meraki123


	This program is free software: you can redistribute it and/or
	modify it under the terms of the GNU General Public License as
	published by the Free Software Foundation, either version 3 of
	the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

'''

testresults = f'''

  last test results {__last_test__} :
  -----------------------------------------

   X = successful tested  ({__MS_version__} , {__MR_version__})
   O = not working yet
   N = not supported


MAC Auth        | Wifi  | MS350 | MS390 |
-------------------------------------------------
MAC Auth        |   X   |   X   |   X   |
+ vlan id       |   X   |   X   |   X   |
+ gpolicy       |   X   |   N   |   N   |
+ gplicy ACL    |   N   |   X   |   X   |
+ vlan name     |   O   |   O   |   N   |

iPSK
-------------------------------------------------
iPSK Auth       |   X   |   N   |   N   |
+ vlan id       |   X   |   N   |   N   |
+ gpolicy       |   X   |   N   |   N   |
+ gplicy ACL    |   N   |   N   |   N   |
+ vlan name     |   O   |   N   |   N   |

802.1X
-------------------------------------------------
802.1X Auth     |   X   |   X   |   X   |
+ vlan id       |   X   |   X   |   X   |
+ gpolicy       |   X   |   N   |   N   |
+ gplicy ACL    |   N   |   X   |   X   |
+ vlan name     |   O   |   O   |   O   |


Adaptive Policy (SGT)
--------------------------------------------------
MAC Auth + SGT  |   X   |   N   |   X   |
   + vlan id    |   X   |   N   |   X   |
802.1X + SGT    |   X   |   N   |   X   |
   + vlan id    |   X   |   N   |   X   |
iPSK + SGT      |   X   |   N   |   N   |
   + vlan id    |   X   |   N   |   N   |

'''


# --------------------------------------------------
# import modules , packages
# --------------------------------------------------
import time, datetime, os, sys, re
from time import sleep
from pathlib import Path
import warnings


# non included modules
try:
	from paramiko import SSHClient
	import paramiko
	from scp import SCPClient
except:
	os.system('pip3 install -r ./configs/requirements.txt')
	from paramiko import SSHClient
	import paramiko
	from scp import SCPClient



#
# settings
# --------------------------------------------------
workdir 		= os.path.abspath(os.curdir)
default_dir		= workdir + '/configs/meraki_freeradius_default_files'
backup_dir		= workdir + '/configs/freearadius_backup'
config_dat		= workdir + '/configs/config.dat'
remote_dir		= '/etc/freeradius/3.0'
temp_dir		= workdir + '/temp'




# -------------------------------------------------------------------------------------------
#	functions
# -------------------------------------------------------------------------------------------

def date_time():
	# create timestamp
	local_date_time = datetime.datetime.now()						#  local_date_time.strftime("%H:%M:%S %d.%m.%Y")   => '15:28:33 06.07.2020'
	date_time = local_date_time.strftime("%Y.%m.%d-%H.%M.%S")		# '2020.07.06-15.32.52'
	return(date_time)


def read_config_dat():
	'''read config.dat , Server IP, username (=root) , user password for ssh login '''
	f = open(config_dat,"r")
	line = f.readline()       										# Zeilenweise einlesen
	for line in f:
		# print(line)
		line = line.split('=')
		if (line[0] == 'server_ip'):
			server_ip = line[1]
			server_ip = server_ip.strip()
		if (line[0] == 'ssh_port'):
			ssh_port = line[1]
			ssh_port = ssh_port.strip()
		if (line[0] == 'login_name'):
			login_name = line[1]
			login_name = login_name.strip()
		if (line[0] == 'login_pwd'):
			login_pwd = line[1]
			login_pwd = login_pwd.strip()
	f.close()
	#
	return(server_ip, ssh_port, login_name, login_pwd)


def check_ssh_connect():
	# CONNECT
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	#
	try:
		ssh = paramiko.SSHClient()
		ssh.load_system_host_keys()
		ssh.set_missing_host_key_policy(paramiko.WarningPolicy())
		ssh.connect(server_ip, ssh_port, login_name, login_pwd)
		os.system('clear')
		print("\n\n\t Connect Check successful\n\n")
		next = input('\t press enter to return')
		return ()
	except:
		print('\n\n')
		print('\t check your config !')
		print('\t is your Raspberry up and running ?')
		print('\n\n')
		next = input('\t press enter to return')
		return()


def config_write(server_ip, ssh_port, login_name, login_pwd):
	f = open(config_dat,"w")							# overwrite existing file
	data = ['# Raspberry Login settings',
			'# ----------------------------',
			'server_ip='+str(server_ip),
			'ssh_port='+str(ssh_port),
			'login_name='+str(login_name),
			'login_pwd='+str(login_pwd)
			]
	i = 0
	for n in data:
		f.write(n+'\n')
		i =+1
	f.close()
	return()


def show_config_dat():
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	os.system('clear')
	print('Raspberry Config :')
	print('-------------------------------------------------------------------')
	print('Raspberry IP   : ', server_ip)
	print('SSH Port       : ', ssh_port)
	print('login name     : ', login_name)
	print('login pwd      : ', login_pwd)
	print('')
	next = input('press enter to return')
	#
	return()


def change_config_dat():
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	os.system('clear')
	print('change config.dat :')
	print('-------------------------------------------------------------------')
	server_ip_new 	= input('Raspberry IP    ['+ server_ip +']:')
	if (server_ip_new == ''):
		server_ip_new = server_ip
	server_ip = server_ip_new

	ssh_port_new 	= input('SSH Port        ['+ ssh_port +']:')
	if (ssh_port_new == ''):
		ssh_port_new = ssh_port
	ssh_port = ssh_port_new

	login_name_new	= input('login name      ['+ login_name +']:')
	if (login_name_new == ''):
		login_name_new = login_name
	login_name = login_name_new

	login_pwd_new 	= input('login password  ['+ login_pwd +']:')
	if (login_pwd_new == ''):
		login_pwd_new = login_pwd
	login_pwd = login_pwd_new
	#
	config_write(server_ip, ssh_port, login_name, login_pwd)
	return()


def restore_meraki_freeradius_default_files():
	'''
	sftp to server and upload files to raspberry

			users, radiusd.conf, clients.conf, eap
	'''
	#
	os.system('clear')
	print('restore default meraki radius configs :')
	print('---------------------------------------------')
	print('------   this needs 2 minutes        -------')
	print('------                                -------')
	print('------       please wait              -------')
	print('---------------------------------------------')
	#
	# CONNECT
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	ssh = paramiko.SSHClient()
	ssh.load_system_host_keys()
	ssh.set_missing_host_key_policy(paramiko.WarningPolicy())
	ssh.connect(server_ip, ssh_port, login_name, login_pwd, compress=True, timeout=65536)
	print("CONNECTED")
	#
	print("starting sftp session")

	# open sftp session
	sftp = ssh.open_sftp()

	# copy data to raspberry   sftp.put(localpath, remotepath)
	sftp.put(default_dir+'/users'			, remote_dir + '/users')
	sftp.put(default_dir+'/radiusd.conf' 	, remote_dir + '/radiusd.conf')
	sftp.put(default_dir+'/clients.conf' 	, remote_dir + '/clients.conf')
	sftp.put(default_dir+'/eap' 			, remote_dir + '/mods-available/eap')

	# close sftp and ssh
	sftp.close()
	ssh.close()

	#
	print("finished")
	input('Press ENTER to continue')
	return()


def upload_users():
	'''
	sftp to server and upload users files to raspberry
	'''
	#
	# CONNECT
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	ssh = paramiko.SSHClient()
	ssh.load_system_host_keys()
	ssh.set_missing_host_key_policy(paramiko.WarningPolicy())
	ssh.connect(server_ip, ssh_port, login_name, login_pwd, compress=True, timeout=65536)
	print("CONNECTED")

	# open sftp session
	sftp = ssh.open_sftp()

	# copy data to raspberry   sftp.put(localpath, remotepath)
	sftp.put(temp_dir+'/users'	, remote_dir + '/users')

	# close sftp and ssh
	sftp.close()
	ssh.close()

	return()



def install_meraki_radius():
	os.system('clear')
	print('installing freeradius on Raspberry :')
	print('---------------------------------------------')
	print('------   this needs 10 minutes        -------')
	print('------                                -------')
	print('------       please wait              -------')
	print('---------------------------------------------')
	input('Press ENTER to start process')
	#
	# CONNECT
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	ssh = paramiko.SSHClient()
	ssh.load_system_host_keys()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	ssh.connect(server_ip, ssh_port, login_name, login_pwd)

	# SEND COMMANDS
	command_01 ="apt-get update"
	command_02 ="apt-get install -y freeradius "
	command_03 ='apt-get install -y freeradius-utils'
	command_04 ='service freeradius stop'
	command_05 ='reboot'

	# exec COMMANDS
	print('updating')
	stdin, stdout, stderr = ssh.exec_command(command_01)
	sleep(30)
	print('installing freeradius')
	stdin, stdout, stderr = ssh.exec_command(command_02)
	sleep(180)
	print('installing freeradius-utils')
	stdin, stdout, stderr = ssh.exec_command(command_03)
	sleep(180)
	print('stopping freeradius service')
	stdin, stdout, stderr = ssh.exec_command(command_04)
	sleep(3)
	print('rebooting')
	stdin, stdout, stderr = ssh.exec_command(command_05)
	sleep(180)
	print('copy default files to raspberry')
	restore_meraki_freeradius_default_files()
	# ssh.close()
	print('finished')
	input('Press ENTER to continue')
	return()



def backup_meraki_radius():
	'''
	scp to server and get files
		save files with date and time

		files to download:
			users, radiusd.conf, clients.conf, eap
	'''
	#
	os.system('clear')
	print('backing up radius configs :')
	print('---------------------------------------------')
	print('------   this needs 2 minutes        -------')
	print('------                                -------')
	print('------       please wait              -------')
	print('---------------------------------------------')
	#
	# CONNECT
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	ssh = paramiko.SSHClient()
	ssh.load_system_host_keys()
	ssh.set_missing_host_key_policy(paramiko.WarningPolicy())
	ssh.connect(server_ip, ssh_port, login_name, login_pwd, compress=True, timeout=65536)

	# sftp client settings
	sftp=ssh.open_sftp()

	# download users, radiusd.conf and clients.conf using scp
	datetime = date_time()
	sftp.get(remote_dir + '/users', 				backup_dir+'/'+datetime+'_users')
	sftp.get(remote_dir + '/radiusd.conf', 			backup_dir+'/'+datetime+'_radiusd.conf')
	sftp.get(remote_dir + '/clients.conf', 			backup_dir+'/'+datetime+'_clients.conf')
	sftp.get(remote_dir + '/mods-available/eap', 	backup_dir+'/'+datetime+'_eap')
	sftp.close()
	ssh.close()

	print('finished')
	input('Press ENTER to continue')
	return()


def clear_temp():
	''' delete all file in the local temp folder'''
	print('rm -f ' + temp_dir + '/*')
	os.system('rm -f ' + temp_dir + '/*')
	return()


def get_file_from_server(remote_file, local_file):
	''' download file from server and store in locally
		remote_file = path + filename
		local_file  = path + filename'''

	# SSH CONNECT to radius server
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	ssh = paramiko.SSHClient()
	ssh.load_system_host_keys()
	ssh.set_missing_host_key_policy(paramiko.WarningPolicy())
	ssh.connect(server_ip, ssh_port, login_name, login_pwd, compress=True, timeout=65536)

	# sftp client settings
	sftp=ssh.open_sftp()

	# download users, radiusd.conf and clients.conf using scp
	datetime = date_time()
	sftp.get(remote_file, local_file)
	sftp.close()
	ssh.close()
	os.system('clear')
	return()


def read_file(file):
	'''
		read file and send content back
	'''
	f = open(file, "rt")			# read file in text mode
	data = f.read()
	return(data)


def check_duplicat_user(user):
	'''
		check if mac/users still exits
		if yes , send back True
	'''
	# get file users from server_ip
	remote_file = remote_dir + '/users'
	local_file  = temp_dir + '/users'
	get_file_from_server(remote_file, local_file)

	# read_file
	file = temp_dir + '/users'
	f = open(file, "rt")			# read file in text mode

	# check for existing user
	duplicate = False
	for line in f:
		# check if first character is not #, space, return or tab
		if (line[:1] != '#') and (line[:1] != '') and (line[:1] != '\t') and (line[:1] != '\n'):
			# print('find username lines : ')
			# print(line.rstrip())
			# copy usernames and print usernames
			found = re.search('\t', line)		# first position of space or tab
			# print('found : ' , found)
			username = line[:found.start()]
			# print('username :' , username,)
			if (username == user):
				duplicate = True
				os.system('clear')
				print('\n\t !! Duplicate user/mac found !!')
				sleep(2)
	f.close()
	return(duplicate)


def get_mac_input():
	valid_mac = False
	duplicate_user = True
	while ((valid_mac != True) and (duplicate_user != False)):
		os.system('clear')
		mac 	= input('\n\t Input MAC [e82a44a133c1] :')
		#
		if (mac == ''):
			mac = 'e82a44a133c1'
		#
		# check if input ia  Mac
		match = re.search(r"[0-9a-f]{12}", mac)
		if not match:
			print('wrong input')
			sleep(1)
			#  os.system('clear')
			valid_mac = False
		else:
			# check if user still exists
			duplicate_user = check_duplicat_user(mac)
			#
	return(mac)


def get_vlan_name_input():
	os.system('clear')
	vlan_name 	= input('\n\t Input VLAN name [testvlan] :')
	#
	if (vlan_name == ''):
		vlan_name = 'testvlan'
	return(vlan_name)


def get_username_pwd_input():
	duplicate_user = True
	os.system('clear')
	while (duplicate_user != False):
		name = input('\n\t user name     :')
		pwd	 = input('\n\t user password :')
		# check if user still exists
		duplicate_user = check_duplicat_user(name)
	#
	return(name, pwd)


def get_vlan_id_input():
	#
	try:
		vlan_id = int(input('vlan id  :'))
		# validate   vlan_id = 1....4095
		if (vlan_id > 0 and vlan_id < 4096):
			return(vlan_id)
		else:
			get_vlan_id_input()
	except:
		get_vlan_id_input()


def get_gpolicy_name_input():
	'''get gpolicy id and validate'''
	gpolicy_name = input('policy name :')
	return(gpolicy_name)


def get_ipsk_key_input():
	'''get ipsk key (! minimum 8 characters) and validate'''
	ipsk_key = input('iPSK key [8 characters minimum] :')
	return(ipsk_key)

def get_sgt_input():
	'''get sgt number and convert to hex sgt
						  100 = hex 0064
					=>    0064-00
	'''
	sgt_number = int(input('sgt number (2...900):'))
	sgt_hex = hex(sgt_number)
	sgt_value = '00' + sgt_hex[2:] + '-00'
	return(sgt_value)


def users_show():
	# get file users from server_ip
	remote_file = remote_dir + '/users'
	local_file  = temp_dir + '/users'
	get_file_from_server(remote_file, local_file)

	# read_file
	file = temp_dir + '/users'
	data = read_file(file)

	# print users
	print(data)
	print('\n\n')
	input('press ENTER to continue')
	return()


def user_add():		# in work
	'''
		clear temp folder
		read file users from radius server and save it in temp folder
		input new user data
		attend to file users in temp folder
		upload users to radius server
		clear temp folder
	'''
	# clear temp folder
	clear_temp()
	# download users and save file in temp folder
	remote_file = remote_dir + '/users'
	local_file  = temp_dir + '/users'
	get_file_from_server(remote_file, local_file)

	# input new user
	print('\n')
	print(' Add new user')
	print(' ========================================')
	print('\n\n')
	#
	print(' MAC authentication')
	print('-----------------------------------------')
	print(' 0	MAC Authentication')
	print(' 1	MAC Auth and VLAN ID assignment')
	print(' 2	MAC Auth and GPolicy assignment')
	print(' 3	MAC Auth and VLAN NAME assignment')
	print(' ')
	print(' iPSK authentication   (MAC + PSK)')
	print('-----------------------------------------')
	print(' 10	iPSK assignment')
	print(' 11	iPSK and VLAN ID assignment')
	print(' 12	iPSK and GPolicy assignment')
	print(' 13	iPSK and VLAN NAME assignment')
	print(' ')
	print(' 802.1X authentication')
	print('-----------------------------------------')
	print(' 20	802.1X Authentication')
	print(' 21	802.1X Auth and VLAN ID assignment')
	print(' 22	802.1X Auth and GPolicy assignment')
	print(' 23	802.1X Auth and VLAN NAME assignment')
	print(' ')
	print(' Adaptive Policy (SGT)')
	print('-----------------------------------------')
	print(' 30	 MAC Auth and STG assignment')
	print(' 31	 MAC Auth and VLAN ID and STG assignment')
	print('')
	print(' 32	 iPSK and SGT assignment')
	print(' 33	 iPSK and VLAN ID and STG assignment')
	print('')
	print(' 34	 802.1X Auth and STG assignment')
	print(' 35	 802.1X Auth and VLAN ID and STG assignment')
	print('')
	print(' 200	clear users')
	print(' 300	Goto Main menue')
	print('')
	select = input('Please select :')
	#
	os.system('clear')

	# MAC Auth
	# ------------------------------------------------------------------------------
	if select == '0':
		mac = get_mac_input()
		#
		f = open(local_file, "a")
		f.write('\n\n\n')
		f.write('#>  MAC Auth \n')
		f.write('#-----------------------------------------------------------\n')
		f.write(mac + '\t Cleartext-Password := ' + mac + "\n")
		f.write('#< \n')
		f.write('\n\n')
		f.close()

		# upload users
		upload_users()

		# clear temp folder
		clear_temp()

	elif select == '1':
		'''MAC Auth and VLAN assignment'''
		mac 	= get_mac_input()
		vlan_id 	= get_vlan_id_input()
		#
		f = open(local_file, "a")
		f.write('\n\n\n')
		f.write('#>  MAC Auth and vlan assignment\n')
		f.write('#-----------------------------------------------------------\n')
		f.write(mac + '\t Cleartext-Password := ' + mac + '\n')
		f.write('\t\t Tunnel-Medium-Type = 6,\n')
		f.write('\t\t Tunnel-Private-Group-ID = ' + str(vlan_id) + ',\n')
		f.write('\t\t Tunnel-Type = VLAN \n')
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()

	elif select == '2':
		'''MAC Auth and GPolicy assignment'''
		mac 			= get_mac_input()
		gpolicy_name 	= get_gpolicy_name_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  MAC Auth and GroupPolicy assignment\n")
		f.write("#-----------------------------------------------------------\n")
		f.write(mac + '\t Cleartext-Password := ' + mac + '\n')
		f.write('\t\t Filter-ID := ' + str(gpolicy_name) + '\n')
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()


	elif select == '3':
		'''MAC Auth and VLAN NAME assignment'''
		mac 		= get_mac_input()
		vlan_name 	= get_vlan_name_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  MAC Auth and vlan name assignment\n")
		f.write("#-----------------------------------------------------------\n")
		f.write(mac + '\t Cleartext-Password := ' + mac + '\n')
		f.write('\t\t Tunnel-Medium-Type = 6,\n')
		f.write('\t\t Tunnel-Private-Group-ID = ' + str(vlan_name) + ',\n')
		f.write('\t\t Tunnel-Type = VLAN \n')
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()


	# iPSK   (== MAC Auth + PSK)
	# ---------------------------------------------------------------------------
	elif select == '10':
		''' iPSK '''
		mac 		= get_mac_input()
		ipsk_key 	= get_ipsk_key_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  iPSK \n")
		f.write("#-----------------------------------------------------------\n")
		f.write(mac + '\t Cleartext-Password := ' + mac + '\n')
		f.write('\t\t Tunnel-password = '+ ipsk_key + '\n')
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()


	elif select == '11':
		''' iPSK and VLAN assignment'''
		mac 		= get_mac_input()
		ipsk_key 	= get_ipsk_key_input()
		vlan_id 	= get_vlan_id_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  iPSK and VLAN assignment\n")
		f.write("#-----------------------------------------------------------\n")
		f.write(mac + '\t Cleartext-Password := ' + mac + '\n')
		f.write('\t\t Tunnel-password = '+ ipsk_key + ',\n')
		f.write('\t\t Tunnel-Medium-Type = 6,\n')
		f.write('\t\t Tunnel-Private-Group-ID = ' + str(vlan_id) + ',\n')
		f.write('\t\t Tunnel-Type = VLAN \n')
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()


	elif select == '12':
		''' iPSK and GPolicy assignment '''
		mac 			= get_mac_input()
		ipsk_key 		= get_ipsk_key_input()
		gpolicy_name 	= get_gpolicy_name_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  iPSK and GPolicy assignment\n")
		f.write("#-----------------------------------------------------------\n")
		f.write(mac + '\t Cleartext-Password := ' + mac + '\n')
		f.write('\t\t Tunnel-password = '+ ipsk_key + ',\n')
		f.write('\t\t Filter-ID := ' + str(gpolicy_name) + '\n')
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()

	elif select == '13':
		''' iPSK and VLAN NAME assignment '''
		mac 			= get_mac_input()
		vlan_name 	= get_vlan_name_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  iPSK and vlan name assignment\n")
		f.write("#-----------------------------------------------------------\n")
		f.write(mac + '\t Cleartext-Password := ' + mac + '\n')
		f.write('\t\t Tunnel-Medium-Type = 6,\n')
		f.write('\t\t Tunnel-Private-Group-ID = ' + str(vlan_name) + ',\n')
		f.write('\t\t Tunnel-Type = VLAN \n')
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()




	# 802.1X User
	# ------------------------------------------------------------------------------
	elif select == '20':
		'''
			802.1X Auth
		'''
		name, pwd = get_username_pwd_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  802.1X Auth \n")
		f.write("#-----------------------------------------------------------\n")
		f.write(name + '\t Cleartext-Password := ' + pwd + "\n")
		f.write('#< \n')
		f.write('\n\n')
		f.close()

		# upload users
		upload_users()

		# clear temp folder
		clear_temp()

	elif select == '21':
		'''
			802.1X Auth and VLAN assignment
		'''
		name, pwd 	= get_username_pwd_input()
		vlan_id 	= get_vlan_id_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  802.1X Auth and VLAN assignment  \n")
		f.write("#-----------------------------------------------------------\n")
		f.write(name + '\t Cleartext-Password := ' + pwd + "\n")
		f.write('\t\t Tunnel-Medium-Type = 6,\n')
		f.write('\t\t Tunnel-Private-Group-ID = ' + str(vlan_id) + ',\n')
		f.write('\t\t Tunnel-Type = VLAN \n')
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()


	elif select == '22':
		'''
			802.1X Auth and GPolicy assignment
		'''
		name, pwd 		= get_username_pwd_input()
		gpolicy_name 	= get_gpolicy_name_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  802.1X Auth and GPolicy assignment  \n")
		f.write("#-----------------------------------------------------------\n")
		f.write(name + '\t Cleartext-Password := ' + pwd + "\n")
		f.write('\t\t Filter-ID := ' + str(gpolicy_name) + '\n')
		f.write('#< \n')
		f.write('\n\n')
		f.close()

		# upload users
		upload_users()

		# clear temp folder
		clear_temp()


	elif select == '23':
		''' 802.1X Auth and VLAN NAME assignment '''
		name, pwd 	= get_username_pwd_input()
		vlan_name 	= get_vlan_name_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  802.1X and vlan name assignment\n")
		f.write("#-----------------------------------------------------------\n")
		f.write(name + '\t Cleartext-Password := ' + pwd + "\n")
		f.write('\t\t Tunnel-Medium-Type = 6,\n')
		f.write('\t\t Tunnel-Private-Group-ID = ' + str(vlan_name) + ',\n')
		f.write('\t\t Tunnel-Type = VLAN \n')
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()


	# Adaptive Policy  (SGT assignment)
	# ------------------------------------------------------------------------------
	elif select == '30':
		''' MAC Auth and STG assignment '''
		mac = get_mac_input()
		sgt	= get_sgt_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  MAC Auth and STG assignment\n")
		f.write("#-----------------------------------------------------------\n")
		f.write(mac + '\t Cleartext-Password := ' + mac + '\n')
		f.write('\t\t Cisco-AVPair = "cts:security-group-tag=' + sgt + '"\n'  )
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()

	elif select == '31':
		''' MAC Auth and VLAN ID and STG assignment '''
		mac 	= get_mac_input()
		vlan_id = get_vlan_id_input()
		sgt		= get_sgt_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  MAC Auth and VLAN ID and STG assignment \n")
		f.write("#-----------------------------------------------------------\n")
		f.write(mac + '\t Cleartext-Password := ' + mac + '\n')
		f.write('\t\t Tunnel-Medium-Type = 6,\n')
		f.write('\t\t Tunnel-Private-Group-ID = ' + str(vlan_id) + ',\n')
		f.write('\t\t Tunnel-Type = VLAN ,\n')
		f.write('\t\t Cisco-AVPair = "cts:security-group-tag=' + sgt + '"\n'  )
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()

	elif select == '32':
		''' iPSK and STG assignment '''
		mac 		= get_mac_input()
		ipsk_key 	= get_ipsk_key_input()
		sgt			= get_sgt_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  iPSK and STG assignment\n")
		f.write("#-----------------------------------------------------------\n")
		f.write(mac + '\t Cleartext-Password := ' + mac + '\n')
		f.write('\t\t Tunnel-password = '+ ipsk_key + ',\n')
		f.write('\t\t Cisco-AVPair = "cts:security-group-tag=' + sgt + '"\n'  )
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()

	elif select == '33':
		''' iPSK and VLAN ID and STG assignment '''
		mac 		= get_mac_input()
		ipsk_key 	= get_ipsk_key_input()
		vlan_id 	= get_vlan_id_input()
		sgt			= get_sgt_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  iPSK and VLAN ID and STG assignment\n")
		f.write("#-----------------------------------------------------------\n")
		f.write(mac + '\t Cleartext-Password := ' + mac + '\n')
		f.write('\t\t Tunnel-password = '+ ipsk_key + ',\n')
		f.write('\t\t Tunnel-Medium-Type = 6,\n')
		f.write('\t\t Tunnel-Private-Group-ID = ' + str(vlan_id) + ',\n')
		f.write('\t\t Tunnel-Type = VLAN ,\n')
		f.write('\t\t Cisco-AVPair = "cts:security-group-tag=' + sgt + '"\n'  )
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()


	elif select == '34':
		''' 802.1X and STG assignment '''
		name, pwd 	= get_username_pwd_input()
		sgt			= get_sgt_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  802.1X and STG assignment\n")
		f.write("#-----------------------------------------------------------\n")
		f.write(name + '\t Cleartext-Password := ' + pwd + "\n")
		f.write('\t\t Cisco-AVPair = "cts:security-group-tag=' + sgt + '"\n'  )
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()

	elif select == '35':
		''' 802.1X Auth and VLAN ID and STG assignment '''
		name, pwd 	= get_username_pwd_input()
		vlan_id 	= get_vlan_id_input()
		sgt			= get_sgt_input()
		#
		f = open(local_file, "a")
		f.write("\n\n\n")
		f.write("#>  802.1X Auth and VLAN ID and STG assignment\n")
		f.write("#-----------------------------------------------------------\n")
		f.write(name + '\t Cleartext-Password := ' + pwd + "\n")
		f.write('\t\t Tunnel-Medium-Type = 6,\n')
		f.write('\t\t Tunnel-Private-Group-ID = ' + str(vlan_id) + ',\n')
		f.write('\t\t Tunnel-Type = VLAN ,\n')
		f.write('\t\t Cisco-AVPair = "cts:security-group-tag=' + sgt + '"\n'  )
		f.write('#< \n')
		f.write('\n\n')
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()



	elif select == '200':
		'''
			clear all users
		'''
		# create empty local users file
		f = open(local_file, "w")
		f.write("#                users file \n")
		f.write("###################################################\n\n\n")
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()

	elif select == '300':
		'''
			Goto main menue
		'''
		return()
	#
	return()


def find_config_blocks_start_and_end():
	'''
		a config block
		'#>'  == start of user config
		'#<'  == end of user config
	'''
	# file in als liste einlsesen. Jede Zeile ist ein Listenelement
	file = (temp_dir + '/users')
	f = open(file).readlines()

	# find startpoints of user configs
	line_counter  = 0  # block counter
	config_block_data = []
	#
	for line in f:
		if (line[:2] == '#>'):
			# print(line)
			# print('start of block :', line_counter)
			start_of_block = line_counter

		if (line[:1] != '#') and (line[:1] != '') and (line[:1] != '\t') and (line[:1] != '\n'):

			found = re.search('\t', line)		# first position of space or tab
			username = line[:found.start()]
			# print('username :' , username)

		if (line[:2] == '#<'):
			end_of_block = line_counter
			config_block_data.extend([[start_of_block, username, end_of_block]])

		line_counter += 1

	# print(config_block_data)
	return(config_block_data)



def find_user_config(user):
	# get user config blocks
	users_blocks = find_config_blocks_start_and_end()
	for item in users_blocks:
		if (item[1] == user):
			start = item[0]
			end   = item[2]
			# print('start : ',start)
			# print('end   : ', end)
	return(start, end)



def delete_user_config(user):
	start, end = find_user_config(user)
	#
	# file in als liste einlsesen. Jede Zeile ist ein Listenelement
	file = (temp_dir + '/users')
	f = open(file).readlines()
	#
	# overwritewrite file 'file' without selected user lines
	nf = open(file, "w")
	i = 0
	for line in f:
		if ((i < start) or (i > end)):
			if (f[i] != '\n'):
				newline = f[i]
				nf.write(newline)
				if ((f[i][:2] == '##') or f[i][:2] == '#<'):
					print(3* '\n')
					nf.write('\n\n\n')
		i += 1
	nf.close()
	return()


def select_user():
	#
	# get user config blocks
	users_blocks = find_config_blocks_start_and_end()
	'''
	[[7, 'aabbccddeef1', 10], [16, 'thomas', 22]]
	'''
	# create select menue
	breite = 55
	rahmenh = '#'
	rahmenv = '|'
	count = 0
	for element in users_blocks:
		username = element[1].rstrip()
		print (rahmenv + ' '.ljust(breite,' ') + rahmenv)
		print (rahmenv + ' ' + str(count).ljust(4,' ') + ' ' + username.ljust(breite-6,' ') + rahmenv)
		print (rahmenv + ' '.ljust(breite,' ') + rahmenv)
		count +=1
	print (''.ljust(breite + 2,rahmenh))
	n = int(input('please enter number :'))
	username = users_blocks[n][1]
	# print(users_blocks[n][1])
	# input('press ENTER to continue')
	return(username)


def user_delete():
	#
	# clear temp folder
	clear_temp()
	# download users and save file in temp folder
	remote_file = remote_dir + '/users'
	local_file  = temp_dir + '/users'
	get_file_from_server(remote_file, local_file)

	# input new user
	print('\n')
	print(' Add new user')
	print(' ----------------------------')
	print(' 1	delete user')
	print(' 2	delete all users\n')
	select = input('Please select :')
	#
	os.system('clear')

	# delete one user
	if select == '1':
		'''
			read users
			list users
			select user
			user config begins with #>
			find user
			delete from '#>' to next '>'
		'''
		# get file users from server_ip
		remote_file = remote_dir + '/users'
		local_file  = temp_dir + '/users'
		get_file_from_server(remote_file, local_file)
		#
		# select one user/mac
		username = select_user()
		#
		# delete user config  '#>' to next '#>'
		delete_user_config(username)
		#
		# upload users
		upload_users()
		#
		# input('press ENTER to continue')
		return()


	# Clear all users
	elif select == '2':
		# create empty local users file
		f = open(local_file, "w")
		f.write("#                users file \n")
		f.write("###################################################\n\n\n")
		f.close()
		# upload users
		upload_users()
		# clear temp folder
		clear_temp()
	else:
		print('wrong input')
		input('press ENTER to continue')

	# read users
	return()



def freeradius_status():
	# CONNECT
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	ssh = paramiko.SSHClient()
	ssh.load_system_host_keys()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	ssh.connect(server_ip, ssh_port, login_name, login_pwd)

	# COMMANDS
	# create status file on raspberry in root dir
	command_01 ="pgrep freeradius > radius_status"

	# exec COMMANDS
	stdin, stdout, stderr = ssh.exec_command(command_01)
	sleep(2)
	ssh.close()

	# download result
	remote_file = '/root/radius_status'
	local_file  = temp_dir + '/radius_status'
	get_file_from_server(remote_file, local_file)

	# open file users
	try:
		f = open(local_file,"r")
		line = f.readline()       					# Zeilenweise einlesen
		if line == '':
			print('\n radius not running')
		else:
			print('\n radius running on pid ', line)
	except:
		print('error')

	input('\n\n press ENTER to continue')

	return()


def freeradius_start():
	''' start freeradius service'''
	# CONNECT
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	ssh = paramiko.SSHClient()
	ssh.load_system_host_keys()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	ssh.connect(server_ip, ssh_port, login_name, login_pwd)

	# COMMANDS
	# create status file on raspberry in root dir
	command_01 ="service freeradius start"

	# exec COMMANDS
	stdin, stdout, stderr = ssh.exec_command(command_01)
	sleep(2)
	ssh.close()

	return()


def freeradius_stop():
	# CONNECT
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	ssh = paramiko.SSHClient()
	ssh.load_system_host_keys()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	ssh.connect(server_ip, ssh_port, login_name, login_pwd)

	# COMMANDS
	# create status file on raspberry in root dir
	command_01 ="service freeradius stop"

	# exec COMMANDS
	stdin, stdout, stderr = ssh.exec_command(command_01)
	sleep(2)
	ssh.close()
	return()


def freeradius_debug_start():
	''' start freeradius in debug mode'''

	# CONNECT
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	ssh = paramiko.SSHClient()
	ssh.load_system_host_keys()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	ssh.connect(server_ip, ssh_port, login_name, login_pwd)

	# COMMANDS
	# create status file on raspberry in root dir
	command_01 ="freeradius -X > freeradius_debug &"

	# exec COMMANDS
	stdin, stdout, stderr = ssh.exec_command(command_01)
	sleep(2)
	ssh.close()
	return()


def freeradius_debug_stop():
	''' stop freeradius debug mode and pring debug file'''
	# Clear temp folder
	clear_temp()			# clear temp folder files
	os.system('clear')      # clear screen

	# CONNECT
	server_ip, ssh_port, login_name, login_pwd = read_config_dat()
	ssh = paramiko.SSHClient()
	ssh.load_system_host_keys()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	ssh.connect(server_ip, ssh_port, login_name, login_pwd)

	# COMMANDS
	# create status file on raspberry in root dir
	command_01 ="pgrep freeradius > freeradius_status"

	# exec COMMANDS
	stdin, stdout, stderr = ssh.exec_command(command_01)
	sleep(2)
	ssh.close()

	# download result
	remote_file = '/root/freeradius_status'
	local_file  = temp_dir + '/freeradius_status'
	get_file_from_server(remote_file, local_file)

	# open file users
	try:
		f = open(local_file,"r")
		line = f.readline()       					# Zeilenweise einlesen
		if line == '':
			print('\n freeradius not running')
		else:
			print('\n freeradius running on pid ', line)
			freeradius_pid = line

			# CONNECT
			server_ip, ssh_port, login_name, login_pwd = read_config_dat()
			ssh = paramiko.SSHClient()
			ssh.load_system_host_keys()
			ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
			ssh.connect(server_ip, ssh_port, login_name, login_pwd)

			# COMMANDS
			# kill freeradius process
			command_01 ="kill -9 " + freeradius_pid

			# exec COMMANDS
			stdin, stdout, stderr = ssh.exec_command(command_01)
			sleep(2)
			ssh.close()
	except:
		print('error')

	# download debug
	remote_file = '/root/freeradius_debug'
	local_file  = temp_dir + '/freeradius_debug'
	get_file_from_server(remote_file, local_file)

	# print freeradius_debug
	data = read_file(local_file)
	print(data)
	input('\n\n press ENTER to continue')
	#
	return()


def show_testmatrix():
	os.system('clear')
	print(testresults)
	input('\n\n press ENTER to continue')
	return()



# -------------------------------------------------------------------------------------------
#	Radius Control Menue
# -------------------------------------------------------------------------------------------
def radius_control_menue():
	''' Freeradius Control'''

	action = ''
	loop = True
	while loop:
		os.system('clear')       # clear screen

		# print menue
		# ------------------
		breite = 55
		rahmenh = '#'
		rahmenv = '|'
		menue = [
				['radius status', freeradius_status],
				['radius start'  , freeradius_start],
				['radius stop' , freeradius_stop],
				['radius debug start'  , freeradius_debug_start],
				['radius debug stop'  , freeradius_debug_stop],
				['Goto main menue', 'break_loop']
				]
		print ('\n What do you like to do ? ')

		count = 0
		for element in menue:
			element = '    ' + element[0]
			print (rahmenv + ' '.ljust(breite,' ') + rahmenv)
			print (rahmenv + ' ' + str(count).ljust(4,' ') + ' ' + element.ljust(breite-6,' ') + rahmenv)
			print (rahmenv + ' '.ljust(breite,' ') + rahmenv)
			count +=1
		print (''.ljust(breite + 2,rahmenh))

		#choose action
		select = int(input (' >> '))
		action = menue[select][1]		# memory address of the selected function

		# run function
		# ---------------
		if (action == 'break_loop'):
			action = ''
			break
		else:
			action()					# jump to memory address
	#
	return()






# -------------------------------------------------------------------------------------------
#	Manage Users Menue
# -------------------------------------------------------------------------------------------
def users_menue():
	'''manage users (MAC, name/pwd , ...)'''
	# clear temp folder
	clear_temp()

	# Menue
	action = ''
	loop = True
	while loop:
		os.system('clear')       # clear screen

		# print menue
		# ------------------
		breite = 55
		rahmenh = '#'
		rahmenv = '|'
		menue = [
				['show users'			, users_show],
				['add user' 			, user_add],
				['delete user'  		, user_delete],
				['Goto radius control menue'  , radius_control_menue],
				['Goto main menue', 'break_loop']
				]
		print ('\n What do you like to do ? ')

		count = 0
		for element in menue:
			element = '    ' + element[0]
			print (rahmenv + ' '.ljust(breite,' ') + rahmenv)
			print (rahmenv + ' ' + str(count).ljust(4,' ') + ' ' + element.ljust(breite-6,' ') + rahmenv)
			print (rahmenv + ' '.ljust(breite,' ') + rahmenv)
			count +=1
		print (''.ljust(breite + 2,rahmenh))

		#choose action
		select = int(input (' >> '))
		action = menue[select][1]		# memory address of the selected function

		# run function
		# ---------------
		if (action == 'break_loop'):

			action = ''
			break
		else:
			action()					# jump to memory address
	#

	return()







# -------------------------------------------------------------------------------------------
#	Setup Menue
# -------------------------------------------------------------------------------------------
def setup_menue():
	''' Setup and configure Meraki-Radius on Raspberry Pi'''

	action = ''
	loop = True
	while loop:
		os.system('clear')       # clear screen

		# print menue
		# ------------------
		breite = 55
		rahmenh = '#'
		rahmenv = '|'
		menue = [
				['show  config', show_config_dat],
				['change config' , change_config_dat],
				['check ssh connect' , check_ssh_connect],
				['install meraki-radius on raspberry'  , install_meraki_radius],
				['backup meraki-radius' , backup_meraki_radius],
				['restore meraki-radius to defaults' , restore_meraki_freeradius_default_files],
				['Goto main menue', 'break_loop']
				]
		print ('\n What do you like to do ? ')

		count = 0
		for element in menue:
			element = '    ' + element[0]
			print (rahmenv + ' '.ljust(breite,' ') + rahmenv)
			print (rahmenv + ' ' + str(count).ljust(4,' ') + ' ' + element.ljust(breite-6,' ') + rahmenv)
			print (rahmenv + ' '.ljust(breite,' ') + rahmenv)
			count +=1
		print (''.ljust(breite + 2,rahmenh))

		#choose action
		select = int(input (' >> '))
		action = menue[select][1]		# memory address of the selected function

		# run function
		# ---------------
		if (action == 'break_loop'):
			action = ''
			break
		else:
			action()					# jump to memory address
	#
	return()



# -------------------------------------------------------------------------------------------
#	Main Menue
# -------------------------------------------------------------------------------------------

def main_menue():
	# os.system('clear')       # clear screen
	breite = 55
	rahmenh = '#'
	rahmenv = '|'
	menue = [
			['show test matrix', show_testmatrix],
			['setup/backup/restore/checks', setup_menue],
			['manage users', users_menue],
			['radius control', radius_control_menue],
			['quit tool', 'quit']
			]
	print ('\n What do you like to do ? ')

	count = 0
	for element in menue:
		element = '    ' + element[0]
		print (rahmenv + ' '.ljust(breite,' ') + rahmenv)
		print (rahmenv + ' ' + str(count).ljust(4,' ') + ' ' + element.ljust(breite-6,' ') + rahmenv)
		print (rahmenv + ' '.ljust(breite,' ') + rahmenv)
		count +=1
	print (''.ljust(breite + 2,rahmenh))
	# select action / function
	select = int(input (' >> '))
	action = menue[select][1]
	return (action)



# --------------------------------------------------
#	MAIN
# --------------------------------------------------
if __name__ == "__main__":
	os.system('clear')
	print(info)
	input('press enter to continue')
	os.system('clear')
	#
	clear_temp()
	#
	loop = True
	while loop:
		os.system('clear')       # clear screen
		action = main_menue()
		# run function
		if (action == 'quit'):
			break
		else:
			action()
		#
	clear_temp()
	os.system('clear')
	print('\n\n finished !')



# ============================================================================================================
